//
//  main.swift
//  Vehicleproj
//
//  Created by MacStudent on 2018-02-02.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var v1=vehicle()
v1.vehicleidentificationNumber="FAG45"
v1.lastMaintained=Date()
v1.totalCapacity=3
v1.printData()
var c=cars()
c.noofdoors=2
c.noofpass=6
c.vehicleidentificationNumber="ghjd78"
c.totalCapacity=6
c.lastMaintained=Date()
c.printData()
var t=truck()
t.numOfAxle=5
t.vehicleidentificationNumber="dfg83"
t.totalCapacity=4
t.lastMaintained=Date()
t.printData()
var b=Bicycle()
b.loc="toroto"
b.printData()


